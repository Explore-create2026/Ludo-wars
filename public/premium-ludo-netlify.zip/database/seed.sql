INSERT INTO `site_settings` (`setting_key`, `setting_value`) VALUES
('site_name', 'Ludo Warss'),
('site_description', 'Premium Online & Offline Ludo Gaming Platform'),
('contact_email', 'swapnil@ludowars.com'),
('adsterra_enabled', '1');

-- Pre-seeded Admin Account (User: swapnil@2026 | Pass: 700124)
INSERT INTO `users` (`id`, `username`, `email`, `password_hash`, `avatar`, `role`, `status`) VALUES
(1, 'swapnil@2026', 'swapnil@ludowars.com', '$2y$10$7Q2V8pG7B1Z4fK9w8h6k0u2J7bV8u3C9x1y5z7w4v2t8r6q4p9s1.', '👑', 'admin', 'active')
ON DUPLICATE KEY UPDATE `username` = 'swapnil@2026';

INSERT INTO `user_statistics` (`user_id`, `games_played`, `games_won`, `win_rate`) VALUES
(1, 15, 12, 80.00)
ON DUPLICATE KEY UPDATE `games_played` = 15;

-- Adsterra Slots (All 9 Real Formats)
INSERT INTO `ad_slots` (`slot_name`, `title`, `is_active`, `ad_code`) VALUES
('adst_header_728x90', 'Leaderboard Banner 728x90', 1, '<script>atOptions = {\'key\' : \'99ae394df84fb5dbacac4a5773b0626e\',\'format\' : \'iframe\',\'height\' : 90,\'width\' : 728,\'params\' : {}};</script><script src=\"https://czernik.org/22/99ae394df84fb5dbacac4a5773b0626e\"></script>'),
('adst_mobile_320x50', 'Mobile Banner 320x50', 1, '<script>atOptions = {\'key\' : \'ca2af78c8c1f739de966cf8102ca1283\',\'format\' : \'iframe\',\'height\' : 50,\'width\' : 320,\'params\' : {}};</script><script src=\"https://czernik.org/22/ca2af78c8c1f739de966cf8102ca1283\"></script>'),
('adst_mid_300x250', 'Medium Rectangle 300x250', 1, '<script>atOptions = {\'key\' : \'fb1b0f2ec70de09ae5c2c67f485eff53\',\'format\' : \'iframe\',\'height\' : 250,\'width\' : 300,\'params\' : {}};</script><script src=\"https://czernik.org/22/fb1b0f2ec70de09ae5c2c67f485eff53\"></script>'),
('adst_footer_468x60', 'Footer Banner 468x60', 1, '<script>atOptions = {\'key\' : \'95a3a992e4ee6f9c6e5013b7eefa0b44\',\'format\' : \'iframe\',\'height\' : 60,\'width\' : 468,\'params\' : {}};</script><script src=\"https://czernik.org/22/95a3a992e4ee6f9c6e5013b7eefa0b44\"></script>'),
('adst_sidebar_160x300', 'Vertical Skyscraper 160x300', 1, '<script>atOptions = {\'key\' : \'396297b4bbf90d1531e767518431bad1\',\'format\' : \'iframe\',\'height\' : 300,\'width\' : 160,\'params\' : {}};</script><script src=\"https://czernik.org/22/396297b4bbf90d1531e767518431bad1\"></script>'),
('adst_native_banner', 'Native Recommendation Widget', 1, '<script async=\"async\" data-cfasync=\"false\" src=\"https://czernik.org/21/7ccd7ba14592e4945465757d2208a513\"></script><div id=\"container-7ccd7ba14592e4945465757d2208a513\"></div>'),
('adst_social_bar', 'Adsterra Social Bar', 1, '<script data-cfasync=\"false\" src=\"https://czernik.org/14/d03561cac0ca46d5723022c7ffbe1c43\"></script>'),
('adst_popunder', 'Adsterra Popunder Script', 1, '<script data-cfasync=\"false\" src=\"https://capitalhospitals.org/1/f96912afd7f79f02978c9c9b659d647a\"></script>'),
('adst_direct_link', 'Adsterra Smart Direct Link', 1, 'https://budgetezy.org/4/e44752077ce27723c24599dd1147fba1');
