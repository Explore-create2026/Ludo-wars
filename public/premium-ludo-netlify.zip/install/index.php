<?php
$lockFile = __DIR__ . '/installed.lock';
if (file_exists($lockFile)) {
    die("Installer Locked. Delete /install/installed.lock to re-install.");
}
$step = isset($_GET['step']) ? (int)$_GET['step'] : 1;
?>
<!DOCTYPE html>
<html>
<head><title>Ludo Warss Installer</title></head>
<body style="background:#0B1020;color:#fff;font-family:sans-serif;padding:40px;text-align:center;">
    <h1>👑 Ludo Warss Installer</h1>
    <p>PHP Version: <?php echo PHP_VERSION; ?> (Requirement: >= 8.2)</p>
    <p>PDO Extension: <?php echo extension_loaded('pdo_mysql') ? 'Active ✓' : 'Missing ✗'; ?></p>
    <p>Master Administrator Configured: <strong>swapnil@2026</strong></p>
</body>
</html>
