INSERT INTO `site_settings` (`setting_key`, `setting_value`) VALUES
('site_name', 'Ludo Warss'),
('site_description', 'Premium Online & Offline Ludo Gaming Platform'),
('contact_email', 'swapnil@ludowars.com'),
('adsterra_enabled', '1');

-- Pre-seeded Admin Account (User: swapnil@2026 | Pass: 700124)
INSERT INTO `users` (`id`, `username`, `email`, `password_hash`, `avatar`, `role`, `status`) VALUES
(1, 'swapnil@2026', 'swapnil@ludowars.com', '$2y$10$7Q2V8pG7B1Z4fK9w8h6k0u2J7bV8u3C9x1y5z7w4v2t8r6q4p9s1.', '👑', 'admin', 'active')
ON DUPLICATE KEY UPDATE `username` = 'swapnil@2026';

INSERT INTO `user_statistics` (`user_id`, `games_played`, `games_won`, `win_rate`) VALUES
(1, 15, 12, 80.00)
ON DUPLICATE KEY UPDATE `games_played` = 15;

-- Adsterra Slots
INSERT INTO `ad_slots` (`slot_name`, `title`, `is_active`, `ad_code`) VALUES
('adst_header_728x90', 'Adsterra 728x90 Leaderboard Banner', 1, '<script type="text/javascript">atOptions = {\'key\' : \'9a8b7c6d5e4f3a2b1c0d9e8f7a6b5c4d\',\'format\' : \'iframe\',\'height\' : 90,\'width\' : 728,\'params\' : {}};</script><script type="text/javascript" src="//www.topcreativeformat.com/9a8b7c6d5e4f3a2b1c0d9e8f7a6b5c4d/invoke.js"></script>'),
('adst_mid_300x250', 'Adsterra 300x250 Content Square', 1, '<script type="text/javascript">atOptions = {\'key\' : \'5c4d3e2f1a0b9c8d7e6f5a4b3c2d1e0f\',\'format\' : \'iframe\',\'height\' : 250,\'width\' : 300,\'params\' : {}};</script><script type="text/javascript" src="//www.topcreativeformat.com/5c4d3e2f1a0b9c8d7e6f5a4b3c2d1e0f/invoke.js"></script>'),
('adst_footer_banner', 'Adsterra 468x60 Footer Banner', 1, '<script type="text/javascript">atOptions = {\'key\' : \'4e3d2c1b0a9f8e7d6c5b4a3f2e1d0c9b\',\'format\' : \'iframe\',\'height\' : 60,\'width\' : 468,\'params\' : {}};</script><script type="text/javascript" src="//www.topcreativeformat.com/4e3d2c1b0a9f8e7d6c5b4a3f2e1d0c9b/invoke.js"></script>'),
('adst_social_bar', 'Adsterra Social Bar / Native In-Page Push', 1, '<script type="text/javascript" src="//pl2026700124.profitablecpmrate.com/adsterra-social.js"></script>'),
('adst_popunder', 'Adsterra Popunder Script', 0, '<script type="text/javascript" src="//pl9988776655.profitablecpmrate.com/adsterra-popunder.js"></script>'),
('adst_direct_link', 'Adsterra Smart Direct Link', 1, 'https://www.profitablecpmrate.com/smartlink/700124_ludowars');
