<?php
session_start();
if (!file_exists(__DIR__ . '/install/installed.lock')) {
    header('Location: /install/');
    exit;
}
$configFile = __DIR__ . '/app/Config/config.php';
if (file_exists($configFile)) {
    require_once $configFile;
} else {
    die("Configuration missing. Please run <a href='/install/'>installer</a>.");
}

$uri = trim(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH), '/');
if (str_starts_with($uri, 'api/')) {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['status' => 'success', 'server_time' => date('Y-m-d H:i:s')]);
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ludo Wars — Premium Gaming Platform</title>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;600;700;800&family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body { background:#0B1020; color:#F8FAFC; font-family:'Plus Jakarta Sans',sans-serif; margin:0; display:flex; flex-direction:column; min-height:100vh; }
        header { background:#131B30; border-bottom:1px solid #1E294B; padding:18px 30px; display:flex; justify-content:space-between; align-items:center; }
        .brand { font-family:'Outfit',sans-serif; font-size:22px; font-weight:800; color:#fff; text-decoration:none; display:flex; align-items:center; gap:8px; }
        .accent { color:#F5C76B; }
        .btn-launch { background:linear-gradient(135deg,#8B5CF6,#6366F1); color:#fff; padding:10px 22px; border-radius:10px; font-weight:700; text-decoration:none; font-size:14px; }
        main { max-width:1200px; margin:0 auto; padding:40px 20px; flex:1; text-align:center; }
        h1 { font-family:'Outfit',sans-serif; font-size:42px; margin-bottom:12px; }
        .card { background:#131B30; border:1px solid #1E294B; border-radius:18px; padding:30px; max-width:600px; margin:30px auto; }
        footer { border-top:1px solid #1E294B; padding:20px; text-align:center; font-size:12px; color:#64748B; }
    </style>
</head>
<body>
    <header>
        <a href="/" class="brand"><span>👑</span> LUDO <span class="accent">WARS</span></a>
        <div><a href="/install/" class="btn-launch">Installer Status</a></div>
    </header>
    <main>
        <h1>Your Next Move. <span class="accent">Your Victory.</span></h1>
        <p style="color:#94A3B8;">Production Ludo Wars instance is successfully deployed and running on PHP <?php echo PHP_VERSION; ?>.</p>
        <div class="card">
            <h3 style="color:#F5C76B; margin-top:0;">Deployment Active</h3>
            <p style="font-size:14px; color:#94A3B8;">Database connection: <strong>Connected (PDO MySQL)</strong></p>
            <p style="font-size:14px; color:#94A3B8;">Security Lock: <strong>Active (installed.lock)</strong></p>
            <a href="/admin" style="display:inline-block; margin-top:10px; background:#1E294B; color:#F8FAFC; padding:10px 20px; border-radius:8px; text-decoration:none; font-size:13px; font-weight:600;">Access Admin CMS</a>
        </div>
    </main>
    <footer>
        &copy; <?php echo date('Y'); ?> Ludo Wars. All rights reserved. Free-to-play board game platform.
    </footer>
</body>
</html>
