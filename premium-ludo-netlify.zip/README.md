# Ludo Wars Deployment Guide
1. Upload premium-ludo-netlify.zip to public_html via hPanel / cPanel File Manager.
2. Extract all files into public_html.
3. Open https://yourdomain.com/install/ in your browser.
4. Complete the 4-step database setup.
